<?php
session_start();
/*
Note : It is recommended to fetch all the parameters from your Database rather than posting static values or entering them on the UI.

POST REQUEST to be posted to below mentioned PayU URLs:

For PayU Test Server:
POST URL: https://test.payu.in/_payment

For PayU Production (LIVE) Server:
POST URL: https://secure.payu.in/_payment
*/

//Required - Unique merchant key provided by PayU along with salt. Salt is used for Hash signature 
//calculation within application and must not be posted or transfered over internet. 
$key = "<Your key>";
$salt = "<Your Salt>";

//Fixed values 
$action = 'https://test.payu.in/_payment'; //for test 
$udf5 = "PAYUBIZ_ANGULARJS_PHP7_KIT"; // Contains information of integration type. Consult to PayU for more details.

/* Request Hash
	----------------
	For hash calculation, you need to generate a string using certain parameters 
	and apply the sha512 algorithm on this string. Please note that you have to 
	use pipe (|) character as delimeter. 
	The parameter order is mentioned below:
	
	sha512(key|txnid|amount|productinfo|firstname|email|udf1|udf2|udf3|udf4|udf5||||||SALT)
	
	Description of each parameter available on html page as well as in PDF.
	
	Case 1: If all the udf parameters (udf1-udf5) are posted by the merchant. Then,
	hash=sha512(key|txnid|amount|productinfo|firstname|email|udf1|udf2|udf3|udf4|udf5||||||SALT)
	
	Case 2: If only some of the udf parameters are posted and others are not. For example, if udf2 and udf4 are posted and udf1, udf3, udf5 are not. Then,
	hash=sha512(key|txnid|amount|productinfo|firstname|email||udf2||udf4|||||||SALT)

	Case 3: If NONE of the udf parameters (udf1-udf5) are posted. Then,
	hash=sha512(key|txnid|amount|productinfo|firstname|email|||||||||||SALT)
	
	In present kit and available PayU plugins UDF5 is used. So the order is -	
	hash=sha512(key|txnid|amount|productinfo|firstname|email|||||udf5||||||SALT)
	
	*/
if(strcasecmp($_SERVER['REQUEST_METHOD'], 'POST') == 0){
	
	$contentType = isset($_SERVER["CONTENT_TYPE"]) ? trim($_SERVER["CONTENT_TYPE"]) : '';	
	if(strcasecmp($contentType, 'application/json;charset=UTF-8') == 0){
		$data = json_decode(file_get_contents('php://input'));
		
		if(!isset($key) || !isset($salt)  || !isset($data->txnid) || !isset($data->amount)  || !isset($data->pinfo) 
			|| !isset($data->fname) || !isset($data->lname) || !isset($data->email) || !isset($data->phone) || !isset($data->address1) || !isset($data->city) 
			|| !isset($data->state) || !isset($data->country) || !isset($data->pg) || !isset($data->zip))
		{
			echo "Invalid input data...all fields are required...";
			exit(0);
		}
		//generate hash with mandatory parameters and udf5
		$hash=hash('sha512', $key.'|'.$data->txnid.'|'.$data->amount.'|'.$data->pinfo.'|'.$data->fname.'|'.$data->email.'|||||'.$udf5.'||||||'.$salt);
		$_SESSION['key'] = $key; //Save key in session
		$_SESSION['salt'] = $salt; //save salt in session to use during Hash validation in response
	
		//Dynamically generate form and return to json for dynamic posting
		$html = '<form action="'.$action.'" id="payment_form" method="post">
			<input type="hidden" id="udf5" name="udf5" value="'.$udf5.'" />
			<input type="hidden" id="surl" name="surl" value="'.getCallbackUrl().'" />
			<input type="hidden" id="furl" name="furl" value="'.getCallbackUrl().'" />
			<input type="hidden" id="curl" name="curl" value="'.getCallbackUrl().'" />
			<input type="hidden" id="key" name="key" value="'.$key.'" />
			<input type="hidden" id="txnid" name="txnid" value="'.$data->txnid.'" />
			<input type="hidden" id="amount" name="amount" value="'.$data->amount.'" />
			<input type="hidden" id="productinfo" name="productinfo" value="'.$data->pinfo.'" />
			<input type="hidden" id="firstname" name="firstname" value="'.$data->fname.'" />
			<input type="hidden" id="Lastname" name="Lastname" value="'.$data->lname.'" />
			<input type="hidden" id="Zipcode" name="Zipcode" value="'.$data->zip.'" />
			<input type="hidden" id="email" name="email" value="'.$data->email.'" />
			<input type="hidden" id="phone" name="phone" value="'.$data->phone.'" />
			<input type="hidden" id="address1" name="address1" value="'.$data->address1.'" />
			<input type="hidden" id="address2" name="address2" value="'.(isset($data->address2)? $data->address2 : '').'" />
			<input type="hidden" id="city" name="city" value="'.$data->city.'" />
			<input type="hidden" id="state" name="state" value="'.$data->state.'" />
			<input type="hidden" id="country" name="country" value="'.$data->country.'" />
			<input type="hidden" id="Pg" name="Pg" value="'.$data->pg.'" />
			<input type="hidden" id="hash" name="hash" value="'.$hash.'" />
			</form>
			<script type="text/javascript"><!--
				document.getElementById("payment_form").submit();	
			//-->
			</script>';
			echo $html;
	
	}
	exit(0);
}

//This function is for dynamically generating callback url to be postd to payment gateway. Payment response will be
//posted back to this url. 
function getCallbackUrl()
{
	$protocol = ((!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] != 'off') || $_SERVER['SERVER_PORT'] == 443) ? "https://" : "http://";
	return $protocol . $_SERVER['HTTP_HOST'] . dirname($_SERVER['PHP_SELF']) . '/response.php';
}

?>
